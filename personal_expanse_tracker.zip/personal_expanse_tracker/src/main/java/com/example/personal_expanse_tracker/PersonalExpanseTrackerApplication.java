package com.example.personal_expanse_tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalExpanseTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonalExpanseTrackerApplication.class, args);
	}

}
