package com.example.personal_expanse_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalExpanseTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
